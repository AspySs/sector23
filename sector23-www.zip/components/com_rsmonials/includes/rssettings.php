<?php
/**
 * @version 2.2
 * @package Joomla 3.x
 * @subpackage RS-Monials
 * @copyright (C) 2013-2022 RS Web Solutions (http://www.rswebsols.com)
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

define('RSWEBSOLS_TABLE_PREFIX', 'rsmonials');
define('RSWEBSOLS_EXTENSION_VERSION', '2.0');
?>